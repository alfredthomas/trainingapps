require_relative 'shareplus_base_screen'

class ItemDetailScreen < SharePlusBaseScreen

  def trait
    "RelativeLayout id:'item_detail_title_relativelayout'"
  end

end