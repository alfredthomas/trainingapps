PORTALS = {
    :testpropertiesdrawer => {
        :name=> "TestPropertiesDrawer",
        :url=> "http://10.15.0.20/sites/AndroidSandbox/TestPropertiesDrawer",
        :username=> "testEditor1",
        :password=> "Password01",
    },
    :testsynclist => {
        :name=> "TestSyncList",
        :url=> "http://10.15.0.20/sites/AndroidSandbox/TestSyncList",
        :username=> "testEditor1",
        :password=> "Password01",
    },
    :testpagecontent => {
        :name=> "TestPageContent",
        :url=> "http://10.15.0.20/sites/AndroidSandbox/TestWebViewerContent/TestPageContent",
        :username=> "Test1",
        :password=> "Password01",
    },
    :testformcontent => {
        :name=> "TestFormContent",
        :url=> "http://10.15.0.20/sites/AndroidSandbox/TestWebViewerContent",
        :username=> "testEditor1",
        :password=> "Password01",
    },
    :androidsandbox => {
        :name=> ":AndroidSandbox",
        :url=> "http://10.15.0.20/sites/AndroidSandbox/",
        :username=> "test1",
        :password=> "Password01",
    },
    :globalsearchsandbox => {
        :name=> "GlobalSearchSandbox",
        :url=> "http://10.15.0.20/sites/AndroidSandbox/GlobalSearchSandbox",
        :username=> "testEditor1",
        :password=> "Password01",
    },
    :globalsearchsandboxsubsiteteam01 => {
        :name=> "Gs Team subsite",
        :url=> "http://10.15.0.20/sites/AndroidSandbox/GlobalSearchSandbox/gsTeamSite01",
        :username=> "testEditor1",
        :password=> "Password01",
    },
    :delayedsearchservice => {
        :name=> "DelayedSearchService",
        :url=> "http://10.15.0.178:8280/examples/globalSearchTests/testSync",
        :username=> "",
        :password=> "",
    },
    :sharepoint2007 => {
        :name=> "sharepoint2007",
        :url=> "http://10.15.0.55",
        :username=> "Administrator",
        :password=> "Southlabs2009",
    },
    :timeoutsearchservice => {
        :name=> "TimeoutSearchService",
        :url=> "http://10.15.0.178:8280/examples/globalSearchTests/testRetry",
        :username=> "",
        :password=> "",
    },
    
}
